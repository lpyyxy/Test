package share;

public enum GenderEnum {
	MALE,FEMALE;
}
