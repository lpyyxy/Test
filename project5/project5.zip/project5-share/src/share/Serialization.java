package share;

public interface Serialization {
	Object formByte();
	byte[] toByte();
}
