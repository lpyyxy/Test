package share;

public interface Operate{
	void delete();
	boolean isDelete();
}
